package br.com.joao.IArea;

public interface AreaCalculavel {
	
	double calcularArea();

}
