package br.com.joao.main;

import br.com.joao.pessoa.Pessoa;
import br.com.joao.pessoa.Atleta;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Pessoa pessoaComum = new Pessoa("Joao", 115, 1.85);
		System.out.println("IMC de "+ pessoaComum.getNome() + ": "+ pessoaComum.calculoIMC());
		
		Atleta atleta = new Atleta("Maria", 65, 1.70, "Corrida");
        System.out.println("IMC ajustado de atleta " + atleta.getNome() + ": " + atleta.calculoIMC());

	}

}
