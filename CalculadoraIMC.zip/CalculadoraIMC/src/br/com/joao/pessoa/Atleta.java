package br.com.joao.pessoa;

public class Atleta extends Pessoa {
	
	private String esportePraticado;

	public Atleta(String nome, double peso, double altura, String esportePraticado) {
		super(nome, peso, altura);
		this.esportePraticado = esportePraticado;
	}
	
	public String getEspotePraticado() {
		return esportePraticado;
	}
	
	public void setEsportePraticado(String esportePraticado) {
		this.esportePraticado = esportePraticado;
	}
	
	public double calculoIMC() {
		double imc = super.calculoIMC();
		return imc * 0.95; //5%
	}
}





